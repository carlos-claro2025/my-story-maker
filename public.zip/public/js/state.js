window.State = {
  filter: 'none',
  brightness: 100,
  saturation: 100,
  zoom: 100,
  ratio: '9:16',
  selected: null,
};
